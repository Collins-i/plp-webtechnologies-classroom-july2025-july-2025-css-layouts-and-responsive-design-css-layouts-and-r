/* =====================================================
   Part 1: JavaScript Basics
   Demonstrate variables, conditionals, and output
===================================================== */

const checkAgeBtn = document.getElementById("checkAgeBtn");
const ageMessage = document.getElementById("ageMessage");

checkAgeBtn.addEventListener("click", () => {
  let age = Number(document.getElementById("ageInput").value);
  // Conditional logic
  if (age >= 18) {
    ageMessage.textContent = `You're ${age} years old — an adult!`;
  } else if (age > 0) {
    ageMessage.textContent = `You're ${age} years old — still a minor.`;
  } else {
    ageMessage.textContent = "Please enter a valid age.";
  }
});


/* =====================================================
   Part 2: Functions — Reusability
===================================================== */

// Function to calculate total cost
function calculateTotal(price, quantity) {
  return price * quantity;
}

// Function to format total as currency
function formatCurrency(amount) {
  return `Ksh ${amount.toFixed(2)}`;
}

document.getElementById("calcTotalBtn").addEventListener("click", () => {
  const price = Number(document.getElementById("priceInput").value);
  const qty = Number(document.getElementById("qtyInput").value);
  const total = calculateTotal(price, qty);
  document.getElementById("totalDisplay").textContent = 
    `Total Cost: ${formatCurrency(total)}`;
});


/* =====================================================
   Part 3: Loops — For, While, ForEach
===================================================== */

const generateListBtn = document.getElementById("generateListBtn");
const numberList = document.getElementById("numberList");

generateListBtn.addEventListener("click", () => {
  numberList.innerHTML = "";

  // Example 1: For loop (count 1 to 10)
  for (let i = 1; i <= 10; i++) {
    const li = document.createElement("li");
    li.textContent = `Number ${i}`;
    numberList.appendChild(li);
  }

  // Example 2: While loop demonstration (console output)
  let count = 5;
  while (count > 0) {
    console.log(`Countdown: ${count}`);
    count--;
  }

  // Example 3: forEach loop example
  const colors = ["red", "green", "blue"];
  colors.forEach(color => console.log(`Color: ${color}`));
});


/* =====================================================
   Part 4: DOM Manipulation
===================================================== */

const toggleColorBtn = document.getElementById("toggleColorBtn");
const addItemBtn = document.getElementById("addItemBtn");
const dynamicList = document.getElementById("dynamicList");

// 1. Toggle a class on the body (dark mode)
toggleColorBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});

// 2. Add a new list item dynamically
addItemBtn.addEventListener("click", () => {
  const newItem = document.createElement("li");
  newItem.textContent = `Dynamic Item ${dynamicList.children.length + 1}`;
  dynamicList.appendChild(newItem);
});

// 3. Change text color on click
dynamicList.addEventListener("click", (e) => {
  if (e.target.tagName === "LI") {
    e.target.style.color = "orange";
  }
});
